<?php
$host = "103.6.245.103";
$username = "wilsandb_smartwell";
$password = "0k;j~dc!^NUf";
$database = "wilsandb_fyp";

// Connect to the database
$mysqli = new mysqli($host, $username, $password, $database);

if ($mysqli ->connect_error) {
    die("Connection Failed ".$mysql->connect_error);
    }


// Connect to the database
$conn = new mysqli($host, $username, $password, $database);

if ($conn ->connect_error) {
    die("Connection Failed ".$mysql->connect_error);
    }

return $mysqli;
return $conn;
?>
